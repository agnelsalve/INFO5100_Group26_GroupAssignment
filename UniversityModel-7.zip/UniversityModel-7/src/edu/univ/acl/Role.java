
package edu.univ.acl;

public enum Role {
    ADMIN, FACULTY, STUDENT, REGISTRAR
}
