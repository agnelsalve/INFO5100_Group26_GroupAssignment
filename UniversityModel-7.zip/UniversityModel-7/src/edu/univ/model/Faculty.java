
package edu.univ.model;

public class Faculty extends Person {
    public Faculty(String id, String fn, String ln, String email, String dept) {
        super(id, fn, ln, email, dept);
    }
}
