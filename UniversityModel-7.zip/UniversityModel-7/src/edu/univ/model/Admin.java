
package edu.univ.model;

public class Admin extends Person {
    public Admin(String id, String fn, String ln, String email, String dept) {
        super(id, fn, ln, email, dept);
    }
}
