
package edu.univ.model;

public class Registrar extends Person {
    public Registrar(String id, String fn, String ln, String email, String dept) {
        super(id, fn, ln, email, dept);
    }
}
